"use strict";
(() => {
  // app/Selector.ts
  var Selector = class {
    /**
     * Get active element, even if it's inside multiple nested Iframes
     * @param document current DOM
     * @returns current active element
     */
    getActiveElement(document2) {
      var _a;
      if (((_a = document2.activeElement) == null ? void 0 : _a.tagName) === "IFRAME") {
        let iframes = document2.getElementsByTagName("iframe");
        for (let i = 0; i < iframes.length; i++) {
          if (iframes[i].contentDocument === null)
            continue;
          let focused = this.getActiveElement(iframes[i].contentDocument);
          if (focused === null)
            continue;
          else
            return focused;
        }
        return null;
      } else if (document2.activeElement === null || document2.activeElement.tagName === "BODY")
        return null;
      else
        return document2.activeElement;
    }
  };

  // ../01-shared/config.ts
  var config = {
    openai: {
      endpoint: "https://api.openai.com/v1/completions",
      model: "text-davinci-003"
    },
    storage: {
      apiKeyKey: "apiKey",
      promptsKey: "prompts"
    },
    ui: {
      color: {
        primary: "crimson",
        secondary: "lightsalmon"
      }
    },
    error: {
      messages: {
        default: "\nERROR: error from OpenAI servers"
      }
    }
  };

  // app/Spinner.ts
  var Spinner = class {
    /**
     * Get html string for a loading spinner
     * @param spinnerId - id of the spinner element
     * @param styleId - id of the style element
     * @returns html for the spinner element and its style
     */
    htmlString(spinnerId, styleId) {
      return `<span id="${spinnerId}"></span>
    <style id="${styleId}">
      #${spinnerId} {
        position: fixed;
        top: 10vmin;
        right: 10vmin;
        height: 10vmin;
        width: 10vmin;
        border-radius: 50%;
        border: 1vmin solid ${config.ui.color.secondary};
        border-bottom-color: ${config.ui.color.primary};
        animation: ${spinnerId} 0.5s linear infinite;
      }

      @keyframes ${spinnerId} {
        0% { transform: rotate(0deg) }
        100% { transform: rotate(360deg) }
      }
    </style>`;
    }
  };

  // content.ts
  chrome.runtime.onConnect.addListener((port) => {
    if (port.name !== "generate")
      return;
    const element = new Selector().getActiveElement(document);
    if (element === null)
      return;
    const id = Math.floor(Math.random() * 1e8).toString();
    const spinnerId = "spinner-textbot-" + id;
    const styleId = "style-textbot-" + id;
    const spinnerString = new Spinner().htmlString(spinnerId, styleId);
    document.body.insertAdjacentHTML("beforeend", spinnerString);
    port.onDisconnect.addListener(() => {
      var _a, _b;
      (_a = document.getElementById(spinnerId)) == null ? void 0 : _a.remove();
      (_b = document.getElementById(styleId)) == null ? void 0 : _b.remove();
    });
    if (element.tagName === "TEXTAREA" || element.tagName === "INPUT") {
      port.onMessage.addListener((message) => {
        let inputOrTeaxtarea = element;
        inputOrTeaxtarea.value += message;
      });
    } else if (element.isContentEditable) {
      port.onMessage.addListener((message) => {
        element.textContent += message;
      });
    }
  });
})();
