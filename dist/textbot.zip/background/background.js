"use strict";
(() => {
  // ../01-shared/config.ts
  var config = {
    openai: {
      endpoint: "https://api.openai.com/v1/completions",
      model: "text-davinci-003"
    },
    storage: {
      apiKeyKey: "apiKey",
      promptsKey: "prompts"
    },
    ui: {
      color: {
        primary: "crimson",
        secondary: "lightsalmon"
      }
    },
    error: {
      messages: {
        default: "\nERROR: error from OpenAI servers"
      }
    }
  };

  // app/Publisher.ts
  var timeoutMilliseconds = 1500;
  var Publisher = class {
    /**
     * Post messages on web page. An error message will be posted
     * if OpenAI is too slow to send messages.
     * @param reader 
     * @param port 
     */
    async publish(reader, port) {
      while (true) {
        let timeout = new Promise((resolve, reject) => setTimeout(resolve, timeoutMilliseconds, ""));
        let result = await Promise.race([reader.read(), timeout]);
        if (typeof result === "string") {
          port.postMessage(config.error.messages.default);
          console.error("ERROR: timeout from OpenAI response stream\n");
          break;
        }
        if (result.done)
          break;
        port.postMessage(result.value);
      }
    }
  };

  // app/Fetcher.ts
  var Fetcher = class {
    constructor(apiKey, endpoint, model) {
      this.apiKey = apiKey;
      this.endpoint = endpoint;
      this.model = model;
    }
    /**
     * Opens a completion stream from GPT and returns a reader for it
     * @param prompt 
     * @returns reader for GPT completion stream
     */
    async getCompletion(prompt) {
      const response = await fetch(this.endpoint, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: "Bearer " + this.apiKey
        },
        body: JSON.stringify({
          model: this.model,
          prompt: prompt.value,
          max_tokens: 4e3,
          stop: "\n\n\xB5\xB5\xB5",
          stream: true
        })
      });
      if (response.body === null)
        return new ReadableStreamDefaultReader(this.getErrorStream());
      const reader = response.body.pipeThrough(new TextDecoderStream()).pipeThrough(this.openAiJSON()).pipeThrough(this.openAiText()).getReader();
      return reader;
    }
    /**
     * Transform a stream from string to JSON
     * @returns `TransformStream` to be used as argument of `ReadableStream.pipeThrough()`
     */
    openAiJSON() {
      return new TransformStream({
        /**
         * @description transform 1 SSE string event into multiple JSON events
         */
        transform(chunkString, controller) {
          let messages = chunkString.replace(/\n\n$/g, "").split("\n\n");
          for (const message of messages) {
            if (message === "data: [DONE]") {
              controller.terminate();
              break;
            }
            if (message.charAt(0) === ":")
              continue;
            if (message === "data: ")
              continue;
            let jsonString = message.replace(/^data: /g, "");
            try {
              controller.enqueue(JSON.parse(jsonString));
            } catch (error) {
              continue;
            }
          }
          ;
        }
      });
    }
    /**
     * Extract OpenAI completion from JSON stream
     * @returns `TransformStream` to be used as argument of `ReadableStream.pipeThrough()`
     */
    openAiText() {
      return new TransformStream({
        transform(chunkJSON, controller) {
          var _a, _b;
          if (chunkJSON.error !== void 0) {
            controller.enqueue(config.error.messages.default);
            console.error("ERROR: OpenAI returned a JSON with an `error` property\n", chunkJSON);
            controller.terminate();
          }
          let text = (_b = (_a = chunkJSON == null ? void 0 : chunkJSON.choices) == null ? void 0 : _a[0]) == null ? void 0 : _b.text;
          if (typeof text !== "string") {
            controller.enqueue(config.error.messages.default);
            console.error("ERROR: OpenAI returned a JSON where `.choices.[0].text` is not a `string`\n", chunkJSON);
            controller.terminate();
          } else
            controller.enqueue(text);
        }
      });
    }
    /**
     * Get a stream that sends only 1 string message stating an error
     * @returns stream
     */
    getErrorStream() {
      return new ReadableStream({
        start(controller) {
          controller.enqueue(config.error.messages.default);
          console.error("ERROR: fetch response.body is null\n");
          controller.close();
        }
      });
    }
  };

  // app/Storage.ts
  async function getData() {
    const storage = await chrome.storage.sync.get(null);
    return {
      apiKey: storage[config.storage.apiKeyKey] || "",
      prompts: storage[config.storage.promptsKey] || []
    };
  }

  // app/ContextMenus.ts
  var ContextMenus = class {
    /**
     * Set 1 context menu for each prompt
     * @param prompts 
     */
    async set(prompts) {
      chrome.contextMenus.removeAll();
      prompts.forEach((prompt, index) => {
        chrome.contextMenus.create({
          id: index.toString(),
          title: "Generate: " + prompt.name,
          type: "normal",
          contexts: ["editable"]
        });
      });
    }
  };

  // background.ts
  chrome.runtime.onInstalled.addListener(async () => {
    const data = await getData();
    chrome.tabs.create({ url: chrome.runtime.getURL("/options/index.html") });
    await new ContextMenus().set(data.prompts);
  });
  chrome.storage.sync.onChanged.addListener(async () => {
    const data = await getData();
    await new ContextMenus().set(data.prompts);
  });
  chrome.contextMenus.onClicked.addListener(async (item, tab) => {
    if (tab === void 0 || tab.id === void 0)
      return;
    const port = chrome.tabs.connect(tab.id, { name: "generate" });
    let id = typeof item.menuItemId === "number" ? item.menuItemId : parseInt(item.menuItemId);
    chrome.action.setBadgeBackgroundColor({ color: config.ui.color.primary, tabId: tab.id });
    chrome.action.setBadgeText({ text: "GPT", tabId: tab.id });
    try {
      const data = await getData();
      const fetcher = new Fetcher(data.apiKey, config.openai.endpoint, config.openai.model);
      const reader = await fetcher.getCompletion(data.prompts[id]);
      const publisher = new Publisher();
      await publisher.publish(reader, port);
    } catch (error) {
      port.postMessage(config.error.messages.default);
      console.error("ERROR:\n", error);
    }
    port.disconnect();
    chrome.action.setBadgeText({ text: "", tabId: tab.id });
  });
})();
